import numpy as np
import pandas as pd
import forte2
import json

reduction = {
    "C1": "C1",
    "Cs": "Cs",
    "Ci": "Ci",
    "C2": "C2",
    "C2v": "C2v",
    "C2h": "C2h",
    "D2": "D2",
    "D2h": "D2h",
    "C3": "C1",
    "C3h": "Cs",
    "D∞h": "D2h",
    "C∞v": "C2v",
    "C3v": "Cs",
    "C4": "C2",
    "C4h": "C2h",
    "C4v": "C2v",
    "C5": "C1",
    "C5v": "Cs",
    "C6": "C2",
    "C6h": "C2h",
    "C6v": "C2v",
    "D2d": "D2",
    "D3":"C2",
    "D3d": "C2h",
    "D3h": "C2v",
    "D4": "D2",
    "D4d": "D2",
    "D4h": "D2h",
    "D5": "C2",
    "D5h": "C2v",
    "D5d": "C2h",
    "D6": "D2",
    "D6h": "D2h",
    "D8h": "D2h",
    "O": "D2",
    "Oh": "D2h",
    "Td": "D2",
    "T": "D2",
    "Th": "D2h",
    "S4": "C2",
    "S6": "Ci",
}

def apply_random_translation_and_rotation(xyz):
    trans = np.random.rand(3) * 5
    M = np.random.rand(3,3)
    u, s, vh = np.linalg.svd(M)
    rot = u @ vh
    if np.linalg.det(rot) < 0:
        rot[:,0] = -rot[:,0]
    xyz = (rot @ xyz.T).T
    xyz += trans[None,:]
    return xyz

if __name__ == "__main__":
    moles = {}
    with open("list.txt", "r") as f:
        lines = f.readlines()
        lines = [line.strip() for line in lines]
        counter = 1
        for line in lines:
            sym, name = line.split(" — ")
            moles[counter] = {"full_pg":sym.lower(), "abelian_pg":reduction[sym].lower(), "name": name.lower()}
            counter += 1


    for i in range(1, 130):
        df = pd.read_csv(f"{i}.txt", sep="\s+", index_col=False, header=None)
        df.iloc[:, 1:] = apply_random_translation_and_rotation(df.iloc[:, 1:].to_numpy())
        df.iloc[:,0] = df.iloc[:,0].map(lambda x: forte2.data.Z_TO_ATOM_SYMBOL[x].capitalize())
        xyz = df.to_csv(path_or_buf=None, sep=" ", index=False, header=False, float_format="%.9f")
        moles[i]["xyz"] = xyz

    with open("otterbein_symmetry_db.json", "w") as f:
        json.dump(moles, f, indent=4)